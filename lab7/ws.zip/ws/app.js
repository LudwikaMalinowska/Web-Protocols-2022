'use strict';
var connect = require("connect");
var app = connect();
var serveStatic = require('serve-static');

var httpServer = require("http").createServer(app);

app.use(serveStatic("public"));

httpServer.listen(3000, function () {
    console.log('Serwer HTTP działa na pocie 3000');
});
