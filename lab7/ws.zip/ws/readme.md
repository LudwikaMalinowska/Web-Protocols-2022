# Sposób użycia

Instalacja zależności:

    npm install

Uruchomienie serwera:

    npm start
